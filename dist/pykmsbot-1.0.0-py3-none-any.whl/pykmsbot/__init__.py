#!/usr/bin/env python
# -*- coding: utf-8 -*-

from .rdBot import wikiWbs_create

from .rdBot import wikiDate_create

from .rdBot import wikiWeek_create

from .rdBot import wikiHr_create

from .rdBot import wikiProject_create


